#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QTimer>
#include "chart.h"
#include <QTextStream>

namespace Ui { class MainWindow; }

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    MainWindow(QWidget *parent = nullptr);
    ~MainWindow();

public slots:
    void clicked_on_button();
    void generateData();

private:
    Ui::MainWindow *ui;

    QTimer *m_timer;
    Chart  *m_chart;
};
#endif // MAINWINDOW_H
