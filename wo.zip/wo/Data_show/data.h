#ifndef DATA_H
#define DATA_H

#include <iostream>
#include <fstream>
#include <vector>
#include <string>
#include <sstream>
#include <cstdlib>
using namespace std;

#define LEN 166100

    string path("znn.csv");
    ifstream fin(path.c_str());
    char c[3];
    double X_size[166100];
    string s;
    fin>>s;
    cout << s << endl;
    int i = 0;
    while(1)
    {
        i++;
        string tmp;
        if(fin.eof()) break;
        getline(fin,tmp,',');
        //cout << tmp << i<<endl;
        if(i%2 == 0)
        {
            float b;
            stringstream ss(tmp);
            ss >> b;
            X_size[i/3] = b;
            //cout << X_size[i/3] << endl;
        }
        else continue;
    }


#endif // DATA_H
