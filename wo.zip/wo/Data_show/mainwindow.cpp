#include "mainwindow.h"
#include "ui_mainwindow.h"
#include <QChartView>
#include <QRandomGenerator>
#include <QValueAxis>
#include <QSplineSeries>
#include <QTextStream>
#include <QFile>
#include <QtCore/QCoreApplication>
#include <QString>
#include <QDebug>
#include <QStringList>


using namespace std;
long timeCount = 0;


MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    m_chart = new Chart();
    m_chart->setTitle("znn.csv.B");
    m_chart->legend()->hide();
    m_chart->setAnimationOptions(QChart::AllAnimations);
    QChartView *chartView = new QChartView(m_chart);
    chartView->setRenderHint(QPainter::Antialiasing);

    ui->verticalLayout->addWidget(chartView);
    m_timer = new QTimer(this);
    connect(ui->pushButton, SIGNAL(clicked()), this, SLOT(clicked_on_button()));
    connect(m_timer, SIGNAL(timeout()), this, SLOT(generateData()));
}

MainWindow::~MainWindow()
{
    delete ui;
}


void MainWindow::clicked_on_button()
{
    m_timer->start(20);
}

void MainWindow::generateData()
{
    QString B;
    QFile file("C:/Users/91879/Desktop/wo/Data_show/znn.txt");
    if(file.open(QFile::ReadOnly | QIODevice::Text))
    {
        int i = 0;
        qDebug() << 2;
        QTextStream in(&file);
        QString strLine;
        while (!in.atEnd())
        {
            i++;
            strLine = in.readLine();
            strLine.remove("\r\n");
            qDebug() << strLine;
            if(i == timeCount)
            {
                B = strLine;
                break;
            }
        }
    }
    m_chart->m_y = B.toDouble();
    m_chart->m_x += 0.02 ;  //实时x坐标
    m_chart->m_series->append(m_chart->m_x, m_chart->m_y);
    timeCount += 1;
    //实现整体平移,必须指明是QChart的方法，不然就是整个界面都平移
    qreal x_min = m_chart->m_x > 3 ? m_chart->m_axisX->min()+0.02 : 0;
    qreal x_max = m_chart->m_x > 3 ? m_chart->m_axisX->max()+0.02 : 5;
    m_chart->m_axisX->setRange(x_min,x_max);
}

